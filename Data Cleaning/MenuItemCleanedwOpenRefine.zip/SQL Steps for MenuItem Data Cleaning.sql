-- Drop database NYCMenu if needed
CREATE DATABASE IF NOT EXISTS NYCMenu;

USE NYCMenu;

-- Drop MenuItem table if it exists
DROP TABLE IF EXISTS `MenuItem`;

-- Create new table 
CREATE TABLE MenuItem ( id INT PRIMARY KEY, menu_page_id INT, price DECIMAL(10,4), dish_id INT, created_at DATETIME, updated_at DATETIME, xpos VARCHAR(12), ypos VARCHAR(12));

-- Load 'dirty' data from MenuItem.csv
LOAD DATA INFILE "C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/MenuItem_clean.csv"
INTO TABLE MenuItem
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;
